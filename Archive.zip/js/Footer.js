import React from "react"
import {Link} from "react-router"

export default React.createClass({

  render() {
    return(
      <footer className="footer_wrapper">
        <section>
        
        </section>
      </footer>
    )
  }
})
